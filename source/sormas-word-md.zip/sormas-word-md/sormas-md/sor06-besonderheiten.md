SOR06. Besonderheiten

## Abstract

## Todesfälle 

Wird ein Todesfall gemeldet, wird eine Aufgabe für „Nachverfolgung POSITIV“
erstellt und im Kommentar „Todesfall Nachverfolgung“ geschrieben und alle
Informationen, die man bereits zu diesem Todesfall hat.

## Bibliography
